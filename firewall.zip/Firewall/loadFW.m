

% folder = 'E:\Albert\Copy\PHD\work\networking\EXPERIMENT\';
% %% Load Data
% % Load features
% featFolder = strcat(folder,'features/');
% featFiles = dir(featFolder);
% features = load( strcat(featFolder,featFiles(3).name));
% 
% for i=4:(length(featFiles))
%     features = [features ; load( strcat(featFolder,featFiles(i).name))];
% end
% 
% % Load CPU
% cpuFolder = strcat(folder,'FW/');
% cpuFiles = dir(cpuFolder);
% cpu = load( strcat(cpuFolder, cpuFiles(3).name));
% 
%for i=4:(length(cpuFiles))
%    cpu = [cpu ; load( strcat(cpuFolder, cpuFiles(i).name))];
%end

addpath('features');


features = load('shortIn_m_0.1_i_20.0.csv');
 features = [features ; load('shortIn1_m_0.1_i_20.0.csv')];
 features = [features ; load('shortIn2_m_0.1_i_20.0.csv')];
 
 features = [features ; load('longIn_m_0.025_i_20.0.csv')];
 features = [features ; load('longIn1_m_0.025_i_20.0.csv')];
 features = [features ; load('longIn2_m_0.025_i_20.0.csv')];
 features = [features ; load('longIn3_m_0.025_i_20.0_d_4.0.csv')];
 features = [features ; load('longIn4_m_0.025_i_20.0_d_3.0.csv')];
 features = [features ; load('longIn5_m_0.025_i_20.0_d_4.0.csv')];
 features = [features ; load('longIn6_m_0.025_i_20.0_d_2.0.csv')];
 features = [features ; load('longIn7_m_0.025_i_20.0_d_2.0.csv')];
 features = [features ; load('longIn8_m_0.025_i_20.0_d_1.5.csv')];
 
 features = [features ; load('shortOut_m_0.1_i_20.0.csv')];
 features = [features ; load('shortOut1_m_0.1_i_20.0.csv')];

 
 rmpath('features');
 addpath('cpu');
 
cpu = load('shortIn.txt');
 cpu = [cpu ; load('shortIn1.txt')];
 cpu = [cpu ; load('shortIn2.txt')];
 
 cpu = [cpu ; load('longIn.txt')];
 cpu = [cpu ; load('longIn1.txt')];
 cpu = [cpu ; load('longIn2.txt')];
 cpu = [cpu ; load('longIn3.txt')];
 cpu = [cpu ; load('longIn4.txt')];
 cpu = [cpu ; load('longIn5.txt')];
 cpu = [cpu ; load('longIn6.txt')];
 cpu = [cpu ; load('longIn7.txt')];
 cpu = [cpu ; load('longIn8.txt')];
 
  cpu = [cpu ; load('shortOut.txt')];
 cpu = [cpu ; load('shortOut1.txt')];
 
 
rmpath('cpu');







%% Randomize
%aux = features;
%aux(:,end+1) = cpu;
%aux =  aux(randperm(end),:);
%cpu = aux(:,end);
%features = aux(:,(1:(end-1)));
