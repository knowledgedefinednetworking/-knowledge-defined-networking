These datasets are obtained by charactarezing the CPU performance of a VNF running on top of an ubuntu 14.04. The traffic is send from another VM to the VFN, which process it and sent it to a third VM. The traffic is replayed from a trace captured in an on-capus link.

Traces are not public due to privacy issues. 