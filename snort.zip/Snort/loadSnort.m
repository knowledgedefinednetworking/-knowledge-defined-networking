addpath('features');

features = load('shortIn_m_0.1_i_20.0.csv');
 features = [features ; load('shortIn1_m_0.1_i_20.0.csv')];
 features = [features ; load('shortIn2_m_0.1_i_20.0.csv')];
 
 features = [features ; load('longIn_m_0.025_i_20.0.csv')];
 features = [features ; load('longIn1_m_0.025_i_20.0.csv')];
 features = [features ; load('longIn2_m_0.025_i_20.0.csv')];
 features = [features ; load('longIn3_m_0.025_i_20.0.csv')];
 features = [features ; load('longIn4_m_0.025_i_20.0.csv')];
 features = [features ; load('longIn5_m_0.025_i_20.0.csv')];
 features = [features ; load('longIn6_m_0.025_i_20.0.csv')];
 features = [features ; load('longIn7_m_0.025_i_20.0.csv')];
 features = [features ; load('longIn8_m_0.025_i_20.0.csv')];
 
 features = [features ; load('shortOut_m_0.1_i_20.0.csv')];
 features = [features ; load('shortOut1_m_0.1_i_20.0.csv')];
 
 features = [features ; load('longOut_m_0.025_i_20.0.csv')];
 features = [features ; load('longOut1_m_0.025_i_20.0.csv')];
 features = [features ; load('longOut2_m_0.025_i_20.0.csv')];
 features = [features ; load('longOut3_m_0.025_i_20.0.csv')];
 features = [features ; load('longOut4_m_0.025_i_20.0.csv')];
 features = [features ; load('longOut5_m_0.025_i_20.0.csv')];
 features = [features ; load('longOut6_m_0.025_i_20.0.csv')]; 

  
rmpath('features');


addpath('cpu');


cpu = load('shortIn0.txt');
 cpu = [cpu ; load('shortIn1.txt')];
 cpu = [cpu ; load('shortIn2.txt')];
 
 cpu = [cpu ; load('longIn0.txt')];
 cpu = [cpu ; load('longIn1.txt')];
 cpu = [cpu ; load('longIn2.txt')];
 cpu = [cpu ; load('longIn3.txt')];
 cpu = [cpu ; load('longIn4.txt')];
 cpu = [cpu ; load('longIn5.txt')];
 cpu = [cpu ; load('longIn6.txt')];
 cpu = [cpu ; load('longIn7.txt')];
 cpu = [cpu ; load('longIn8.txt')];
 
 cpu = [cpu ; load('shortOut0.txt')];
 cpu = [cpu ; load('shortOut1.txt')];
 
 cpu = [cpu ; load('longOut0.txt')];
 cpu = [cpu ; load('longOut1.txt')];
 cpu = [cpu ; load('longOut2.txt')];
 cpu = [cpu ; load('longOut3.txt')];
 cpu = [cpu ; load('longOut4.txt')];
 cpu = [cpu ; load('longOut5.txt')];
 cpu = [cpu ; load('longOut6.txt')];
 
rmpath('cpu');