clear all
close all

loadSnort;
snortCPU = mean(cpu);
loadFW;
fwCPU = mean(cpu);
loadCon;
ovsCPU = mean(cpu);
clear cpu features


load('resultsSnort/errorSweepSnort');
snortT = mseAvgT;
snortE = mseAvgE;
snortV = mseAvgV;

load('resultsOVS/errorSweepCon');
ovsT = mseAvgT;
ovsE = mseAvgE;
ovsV = mseAvgV;

load('resultsFW/errorSweepFW');
fwT = mseAvgT;
fwE = mseAvgE;
fwV = mseAvgV;

clear mseAvgT mseAvgE mseAvgV

snort = sqrt(0.4*snortE + 0.5*snortV + 0.1*snortT)/snortCPU*100;
ovs   = sqrt(0.4*ovsE + 0.5*ovsV + 0.1*ovsT)/ovsCPU*100;
fw    = sqrt(0.4*fwE + 0.5*fwV + 0.1*fwT)/fwCPU*100;

clear snortT snortE snortV ovsT ovsE ovsV fwT fwV fwE

%%
% fbones = [3 4 11 46 47 49 50 51 52 53 54 58 60 81];
% bar([fw(fbones)'; ovs(fbones)'; snort(fbones)']')
% set(gca,'XTickLabel',{'numPackets', 'totalBytes','ipSrcDst', 'numTCP', 'numUDP', 'srcPortTCP', 'dstPortTCP',...
%     'srcPortUDP', 'dstPortUDP', 'ipSrcPort', 'ipDstPort', 'flows', 'flowsUDP', 'httpPackets'})
% rotateXLabels( gca(), 45 )
% 
% ylim([5 10])
% ylabel('Error in percentage');
% legend('Firewall','OVS','Snort');

x = 1:88;
plot(x,fw,x,ovs,x,snort,'LineWidth',2);
legend('fw','ovs','snort');
xlabel('unsorted features');
ylabel('error [%]');
ylim([0 30])
xlim([1 87])

figure
fw = sort(fw);
fw = fw(2:87);

ovs = sort(ovs);
ovs = ovs(2:87);

snort = sort(snort);
snort = snort(2:87);

x = 1:86;
plot(x,fw,x,ovs,x,snort,'LineWidth',2);
legend('fw','ovs','snort');
xlabel('sorted features');
ylabel('averagee error [%]');
