loadFW
cpuFW = cpu;
featuresFW = features;
featuresFW(:,1) = 1;

loadCon
cpuOVS = cpu;
featuresOVS = features(:,1:87);
featuresOVS(:,1) = 2;

loadSnort
cpuSnort = cpu;
featuresSnort = features;
featuresSnort(:,1) = 3;

features = [featuresFW; featuresOVS; featuresSnort];
cpu = [cpuFW; cpuOVS; cpuSnort];

clear featuresFW featuresOVS featuresSnort
clear cpuFW cpuOVS cpuSnort