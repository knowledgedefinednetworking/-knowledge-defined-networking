clear all
% close all

titleName = 'Firewall';
%  load('resultsSnort/snortNet');loadSnort;
% load('resultsSnort/miniNet');
load('resultsFW/miniNet');
% load('resultsOVS/miniNet');

nPmin = min(numPackets);
nPmax = max(numPackets);
nFmin = min(numFlows);
nFmax = max(numFlows);

figure;



% 3D
subplot(1,3,1)

f = zeros(200*200, 2);
eixPackets = linspace(nPmin, nPmax, 200);
eixFlows = linspace(nFmin, nFmax, 200);
for i = 1:200
    k = 200*(i-1)+1;
    L = k:(k+199);
    f(L,1) = eixPackets(i);
    f(L,2) = eixFlows;
end
cpu1 = net(f');
cpu1 = reshape(cpu1,[200 200]);
pdata = [numPackets numFlows cpu];
scatter3(numPackets, numFlows, cpu);
ylim([nFmin nFmax]);
xlim([nPmin nPmax]);
xlabel('Num Packets');
ylabel('Num Flows');
zlabel('CPU consumption');
hold on
% data = [linspace(nPmin, nPmax, 200); linspace(nFmin, nFmax, 200); cpu1];
surf(linspace(nPmin, nPmax, 200), linspace(nFmin, nFmax, 200), cpu1);
ylim([0 1.2e4]);
xlim([3e4 7e4]);

%% only packets
subplot(1,3,2)


f = zeros(200, 2);
f(:,1) = linspace(nPmin, nPmax, 200);
cpu1 = net(f');
% figure
scatter(numPackets, cpu);%, numFlows, cpu);
hold on
plot(linspace(nPmin, nPmax, 200),cpu1);
xlim([3e4 7e4]);
xlabel('Num Packets');
ylabel('CPU consumption');

title(titleName);

%% only flows
subplot(1,3,3)

f = zeros(200, 2);
f(:,2) = linspace(nFmin, nFmax, 200);
cpu1 = net(f');
% figure
scatter(numFlows, cpu);
hold on
plot(linspace(nFmin, nFmax, 200),cpu1);
xlim([0 1.2e4]);
xlabel('Num Flows');
ylabel('CPU consumption');
