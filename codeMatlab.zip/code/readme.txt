These are MATLAB (R) functions and scripts. They implement different plots and comparisons among experiments  of the VNF experiment.
The files needed to read each dataset are included in the dataset file.

