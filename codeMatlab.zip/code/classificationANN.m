loadFW
featuresFW = features;
featuresFW(:,1) = cpu;

loadCon
featuresOVS = features(:,1:87);
featuresOVS(:,1) = cpu;

loadSnort
featuresSnort = features;
featuresSnort(:,1) = cpu;

features = [featuresFW; featuresOVS; featuresSnort];

output = zeros(length(features),3);
output(1:(length(featuresFW)),1) = 1;
output((length(featuresFW)+1):(length(featuresFW)+length(featuresOVS)),2) = 1;
output((length(featuresFW)+length(featuresOVS)+1):end,3) = 1;

clear featuresFW featuresOVS featuresSnort
clear cpuFW cpuOVS cpuSnort cpu
