clear all
load net
%load features

titles = char('batchNum','lastTS','numPackets','totalBytes','avgInterAT','stdInterAT','avgLength','stdLength','ipSrc','ipDst','ipSrcDst','ipv4','ipv6','icmp4','icmp6','ipMaskSrc[30]','[29]','[28]','[27]','[26]','[25]','[24]','[23]','[22]','[21]','[20]','[19]','[18]','[17]','[16]','ipMaskDst[30]','[29]','[28]','[27]','[26]','[25]','[24]','[23]','[22]','[21]','[20]','[19]','[18]','[17]','[16]','numTCP','numUDP','othersL4','srcPortTCP','dstPortTCP','srcPortUDP','dstPortUDP','ipSrcPort','ipDstPort','tcpSyn','tcpFin','tcpRes','flows','flowsTCP','flowsUDP','flowsOther','avgPacketsFlowTCP','stdPacketsFlowTCP','avgPacketsFlowUDP','stdPacketsFlowUDP','avgPacketsFlowOther','stdPacketsFlowOther','avgInterAtFlowTCP','stdInterAtFlowTCP','avgInterAtFlowUDP','stdInterAtFlowUDP','avgInterAtFlowOther','stdInterAtFlowOther','avgLengthFlowTCP','stdLengthFlowTCP','avgLengthFlowUDP','stdLengthFlowUDP','avgLengthFlowOther','stdLengthFlowOther','onePacketFlows','httpPackets','httpFlows','sslPackets','sslFlows','smtpPackets','smtpFlows','auxFet','auxFet2');

MIN = min(features);
MAX = max(features);

N = 20;

data  = zeros(88,N);
fzero = zeros(1,N);

% aviobj = avifile('mymovie.avi','fps',1,'compression', 'Cinepak');%,'colormap',[200 200 200]); 


for i=1:88
    disp(i)
    fev = linspace(MIN(i), MAX(i), N);
    data(i,:) = fev;
    cpu = net(data);
    
    h = plot(fev, cpu);
    title(titles(i,:));
    data(i,:) = fzero;
    ylabel('CPU [Mbps]')
    xlabel(strcat(titles(i,:)));
    ylim([min(cpu) max(cpu)]);
    xlim([MIN(i) MAX(i)]);
    
    print(strcat('images/',titles(i,:)),'-dpng')
    
    
%     frame = getframe(gcf);
%     aviobj = addframe(aviobj,frame);
    
%     close all
   
   pause
end

% aviobj = close(aviobj);
