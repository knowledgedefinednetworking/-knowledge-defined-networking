loadCon;

features(:,1) = 1;
[b,bint,r,rint,stats]  = regress(cpu,features);


mse = sum((features*b-cpu).^2)/length(cpu);