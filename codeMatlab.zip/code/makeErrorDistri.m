clear all
close all

load('resultsFW/net');
cpuPred = (net(features'))';
difErrFW = abs(cpu - cpuPred);
perErrFW = difErrFW./cpu;
lenCPUfw = length(cpu);


load('resultsOVS/net2');
% load('resultsOVS/netCon');
cpuPred = (net(features'))';
difErrOVS = abs(cpu - cpuPred);
perErrOVS = difErrOVS./cpu;
lenCPUovs = length(cpu);

load('resultsSnort/snortNet');
loadSnort
cpuPred = (net(features'))';
difErrSnort = abs(cpu - cpuPred);
perErrSnort = difErrSnort./cpu;
lenCPUsnort = length(cpu);

%% Plots differential
figure
[yFW,xFW] = hist(difErrFW,100);
yFW = cumsum(yFW)/lenCPUfw;

[yOVS,xOVS] = hist(difErrOVS,100);
yOVS = cumsum(yOVS)/lenCPUovs;

[ySnort,xSnort] = hist(difErrSnort,100);
ySnort = cumsum(ySnort)/lenCPUsnort;

plot(xFW, yFW, xOVS, yOVS, xSnort, ySnort, 'LineWidth',2);
legend('Firewall', 'OVS+controller', 'Snort');
ylabel('Probability');
xlim([0 100]);
xlabel('Differential error [MHz]');

%% Plots percentual
figure
[yFW,xFW] = hist(perErrFW*100,200);
yFW = cumsum(yFW)/lenCPUfw;

[yOVS,xOVS] = hist(perErrOVS*100,200);
yOVS = cumsum(yOVS)/lenCPUovs;

[ySnort,xSnort] = hist(perErrSnort*100,200);
ySnort = cumsum(ySnort)/lenCPUsnort;

plot([0 xFW], [0 yFW], [0 xOVS], [0 yOVS], [0 xSnort], [0 ySnort], 'LineWidth',2);
legend('Firewall', 'OVS+controller', 'Snort', 'Location','Southeast');
ylabel('Probability');
xlim([0 14]);
xlabel('Error [%]');