clear all
close all

%AMB sense 88.84
loadCon
%allTogether


% numPackets = features(:,3);
% numFlows = features(:,58);
% features = [numPackets numFlows];


% trampa
%% Initialize ANN
net = fitnet(5);
%view(net)

[net,tr] = train(net,features',cpu');
nntraintool

plotperform(tr)

%% END
%kk = 1:149;
%plot(kk,features',kk,cpu*40,'LineWidth',2)
%legend('flows','packets','portsSrc','CPU *33')

%plotregression(cpu,y)

