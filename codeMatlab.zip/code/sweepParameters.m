clear all
close all

loadSnort
N = length(cpu);
mseAvgT = zeros(88,1);
mseAvgV = zeros(88,1);
mseAvgE = zeros(88,1);
RMAX = 50;

 for r = 1:RMAX
     disp(r)
    for i = 1:87
        %disp(i)

        net = fitnet(5);
        net.trainParam.showWindow = false;

        f = features(:,i);

        [net,tr] = train(net,f',cpu');
        nntraintool

        mseAvgT(i,1) = mseAvgT(i,1) + tr.best_tperf;
        mseAvgV(i,1) = mseAvgV(i,1) + tr.best_vperf;        
        mseAvgE(i,1) = mseAvgE(i,1) + tr.best_perf;
        
        clear net test
    end
 end

mseAvgT(:,1) = mseAvgT(:,1)/RMAX;
mseAvgV(:,1) = mseAvgV(:,1)/RMAX;
mseAvgE(:,1) = mseAvgE(:,1)/RMAX;

save('errorSweepSnort','mseAvgT','mseAvgV','mseAvgE');

%bar(mseAvg, BarStyle = Boxes))