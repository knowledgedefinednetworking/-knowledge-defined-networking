clear all
close all

%% load FW
addpath('E:\Albert\Copy\PHD\MATLAB\vSwitch\realTraffic\generic\TS');

cpu = load('shortIn.txt');
 cpu = [cpu ; load('shortIn1.txt')];
 cpu = [cpu ; load('shortIn2.txt')];
 
 cpu = [cpu ; load('longIn.txt')];
 cpu = [cpu ; load('longIn1.txt')];
 cpu = [cpu ; load('longIn2.txt')];
 cpu = [cpu ; load('longIn3.txt')];
 cpu = [cpu ; load('longIn4.txt')];
 cpu = [cpu ; load('longIn5.txt')];
 cpu = [cpu ; load('longIn6.txt')];
 cpu = [cpu ; load('longIn7.txt')];
 cpu = [cpu ; load('longIn8.txt')];
 
  cpu = [cpu ; load('shortOut.txt')];
 cpu = [cpu ; load('shortOut1.txt')];
 

 
 cpuFW = cpu;
 
rmpath('E:\Albert\Copy\PHD\MATLAB\vSwitch\realTraffic\generic\TS');

%$ load Snort


addpath('E:\Albert\Copy\PHD\work\networking\EXPERIMENT\SNORT');


cpu = load('shortIn0.txt');
 cpu = [cpu ; load('shortIn1.txt')];
 cpu = [cpu ; load('shortIn2.txt')];
 
 cpu = [cpu ; load('longIn0.txt')];
 cpu = [cpu ; load('longIn1.txt')];
 cpu = [cpu ; load('longIn2.txt')];
 cpu = [cpu ; load('longIn3.txt')];
 cpu = [cpu ; load('longIn4.txt')];
 cpu = [cpu ; load('longIn5.txt')];
 cpu = [cpu ; load('longIn6.txt')];
 cpu = [cpu ; load('longIn7.txt')];
 cpu = [cpu ; load('longIn8.txt')];
 
 cpu = [cpu ; load('shortOut0.txt')];
 cpu = [cpu ; load('shortOut1.txt')];
 
   cpu = [cpu ; load('longOut0.txt')];
 cpu = [cpu ; load('longOut1.txt')];
 cpu = [cpu ; load('longOut2.txt')];
 cpu = [cpu ; load('longOut3.txt')];
 cpu = [cpu ; load('longOut4.txt')];
 cpu = [cpu ; load('longOut5.txt')];
 cpu = [cpu ; load('longOut6.txt')];
 
cpuSnort = cpu;
 
rmpath('E:\Albert\Copy\PHD\work\networking\EXPERIMENT\SNORT');


%% load OVS

addpath('E:\Albert\Copy\PHD\work\networking\EXPERIMENT\CONT_OVS');


cpu = load('shortIn0.txt');
 cpu = [cpu ; load('shortIn1.txt')];
 cpu = [cpu ; load('shortIn2.txt')];
 
  cpu = [cpu ; load('longIn0.txt')];
  cpu = [cpu ; load('longIn1.txt')];
  cpu = [cpu ; load('longIn2.txt')];
%  cpu = [cpu ; load('longIn3.txt')];
%  cpu = [cpu ; load('longIn4.txt')];
%  cpu = [cpu ; load('longIn5.txt')];
%  cpu = [cpu ; load('longIn6.txt')];
%  cpu = [cpu ; load('longIn7.txt')];
%  cpu = [cpu ; load('longIn8.txt')];
 
 cpu = [cpu ; load('shortOut0.txt')];
 cpu = [cpu ; load('shortOut1.txt')];

 cpuOVS = cpu;
rmpath('E:\Albert\Copy\PHD\work\networking\EXPERIMENT\CONT_OVS');


%% plots

x = 1:length(cpu);

plot(x, cpuFW, x, cpuSnort, x, cpuOVS, 'linewidth',2);
legend('FW', 'Snort', 'OVS');

figure
meanFW = mean(cpuFW);
meanSnort = mean(cpuSnort);
meanOVS = mean(cpuOVS);
plot(x, cpuFW/meanFW, x, cpuSnort/meanSnort, x, cpuOVS/meanOVS, 'linewidth',1);
legend('FW', 'Snort', 'OVS');