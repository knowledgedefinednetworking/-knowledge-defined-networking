This code is in python and uses the library pylearn2 (http://deeplearning.net/software/pylearn2/).

The file "run.sh" contains a valid configuration of the hyper-parameters of the ANN.
The file "sysTest.py" takes the comand line arguments and translate them to python varuables.
The file "trainML.py" uses the python variables to read the dataset and train the ANN. It also calculates the train/validation/test erros. 