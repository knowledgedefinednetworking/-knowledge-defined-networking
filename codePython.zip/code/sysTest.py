# -*- coding: utf-8 -*-
"""
Created on Thu Oct 22 16:54:57 2015

@author: albert
"""

import sys, getopt
import matplotlib
matplotlib.use('Agg')
import trainML as ML

def main(argv):
    numEpoch = 2
    learningRate = 0.007
    nhnSM = 196
    nhnRL = 196
    normY = 3
    deepL = 1
    yPred = 'util'
    fileName = 'outputMultipleRouting_5.txt'
    nNet = 1
    useRouting=2
    normT=1
    normR=1
    centerF=1
    startPar = 20
    saturatePar = 200
    decayLR = 0.2
    iniMomentum = 0.2
    endMomentum = 0.8
    regRL = 0
    regSM = 0
    regLin = 0
    samples = 0


    try:
        opts, args = getopt.getopt(argv,"he:l:n:m:f:d:y:o:r:t:u:c:s:p:a:i:j:w:x:z:N:S:",["numEpoch=","learningRate=","numHidNeurons=","numHidNeurons2=","yFactor=","deepL=","yPred=","outputUsed=","normR=","normT=","useRouting=",\
                "centerF=","startPar=","satPar=","decayLR=","iniMom=","endMom=","regSM=","regRL=","regLin=","network=","samples="])
    except getopt.GetoptError:
        print 'test.py -e <numEpoch>  -l <learningRate> -n <numHiddenLayersSigmpod> -m <numHiddenLayersRectified> -f <factorY> -d <deepL> -y <prefictionY (util/delay)> -o <fileUsedAsOutput> -r <normR> -t <normT> \
                -u <useRouting> -c <centerF> -s <startPar> -p <satPar> -a <decayLR> -i <iniMomentum> -j <endMomentum> -w <regSM> -x <regRL> -z <regLin>'
        sys.exit(2)
    for opt, arg in opts:
        if opt == '-h':
            print 'test.py -e <numEpoch>  -l <learningRate> -n <numHiddenLayersSigmpod> -m <numHiddenLayersRectified> -f <factorY> -d <deepL> -y <prefictionY (util/delay)> -o <fileUsedAsOutput> -r <normR> -t <normT> \
                    -u <useRouting> -c <centerF> -s <startPar> -p <satPar> -a <decayLR> -i <iniMomentum> -j <endMomentum> -w <regSM> -x <regRL> -z <regLin>'
            sys.exit()
        elif opt in ("-e", "--numEpoch"):
            numEpoch = int(arg)
        elif opt in ("-l", "--learningRate"):
            learningRate = float(arg)
        elif opt in ("-n", "--numHidNeurons"):
            nhnSM = int(arg)
        elif opt in ("-m", "--numHidNeurons2"):
            nhnRL = int(arg)
        elif opt in ("-f", "--yFactor"):
            normY = float(arg)
        elif opt in ("-d", "--deepL"):
            deepL = int(arg)
        elif opt in ("-y", "--yPred"):
            yPred = arg
        elif opt in ("-o", "--outputUsed"):
            fileName = arg
        elif opt in ("-N", "--network"):
            nNet = int(arg)
        elif opt in ("-r", "--normR"):
            normR = float(arg)
        elif opt in ("-t", "--normT"):
            normT = float(arg)
        elif opt in ("-u", "--useRouting"):
            useRouting = int(arg)
        elif opt in ("-c", "--centerF"):
            centerF = int(arg)

        elif opt in ("-s", "--startPar"):
            startPar = int(arg)
        elif opt in ("p-", "--satPar"):
            saturatePar = int(arg)
        elif opt in ("-a", "--decayLR"):
            decayLR = float(arg)
        elif opt in ("-i", "--iniMom"):
            iniMomentum = float(arg)
        elif opt in ("-j", "--endMom"):
            endMomentum = float(arg)
        elif opt in ("-w", "--regSM"):
            regSM = float(arg)
        elif opt in ("-x", "--regRL"):
            regRL = float(arg)
        elif opt in ("-z", "--regLin"):
            regLin = float(arg)
        elif opt in ("-S", "--samples"):
            samples = int(arg)
                 
         
    print 'Num Epochs:', 2*numEpoch/2
    print 'Initial Learning Rate: ', 2*learningRate/2
    print 'Num Hidden Neurons Sigmoid: ', 2*nhnSM/2
    print 'Num Hidden Neurons Rectified: ', 2*nhnRL/2
    print 'Factor Y: ', 2*normY/2
    print 'Deep Learning layers: ', 2*deepL/2
    print 'Y prediction: ', yPred
    print 'FileUsed: ', fileName
    print 'Network: ', nNet
    print 'Samples: ', samples
    print 'Routing normalizing factor: ', normR 
    print 'Traffic normalizing factor: ', normT
    print 'Using Routing (0 no, 1 one, all): ', useRouting 
    print 'Center features?: ', centerF 
    
    print 'Start Parameter: ', `startPar`
    print 'Saturate parameter: ', `saturatePar`
    print 'Decay LearningRate: ', `decayLR`
    print 'InitialMomentum: ', `iniMomentum`
    print 'FinalMomentum: ', `endMomentum`

    print 'Regularization value Sigmoid: ', `regSM`
    print 'Regularization value Rectified: ', `regRL`
    print 'Regularization value Linear: ', `regLin`

    ML.runML(numEpoch=numEpoch, learningRate=learningRate, numHidNeuronsSM=nhnSM, numHidNeuronsRL=nhnRL, normY=normY, deepL=deepL, yPred=yPred,\
            fileData=fileName, useRouting=useRouting, normR=normR, normT=normT, centerF=centerF, startPar=startPar, saturatePar=saturatePar, \
            decayLR=decayLR, iniMomentum=iniMomentum, endMomentum=endMomentum, regSM = regSM, regLin = regLin, regRL = regRL, network = nNet, samples = samples);

  

if __name__ == "__main__":
   main(sys.argv[1:])
