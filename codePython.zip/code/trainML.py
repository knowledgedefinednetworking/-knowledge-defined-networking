# -*- coding: utf-8 -*-
"""
Created on Mon Nov 23 19:13:25 2015

@author: albert
"""
import numpy as np
import pylearn2.datasets as mlD
import pylearn2.models.mlp as mlp
import pylearn2.training_algorithms.sgd as sgd
import pylearn2.termination_criteria as tc
import pylearn2.train_extensions.best_params as bp
import pylearn2.training_algorithms.learning_rule as lr
import pylearn2.costs.cost as costs
import pylearn2.costs.mlp as mlp_costs
import pylearn2.utils.serial as serial
import theano
import matplotlib.pyplot as plt
from datetime import datetime




    
def runML(numEpoch = 800, learningRate = 0.007, numHidNeuronsSM=392, numHidNeuronsRL=392, normY=3, deepL=1, \
    yPred='util', fileData='outputMultipleRouting_5.txt', network=1, useRouting=2, normT=5., normR=4., centerF=1, \
    startPar = 20, saturatePar = 200, decayLR = 0.2, iniMomentum = 0.2, endMomentum = 0.8, \
    regSM = 0, regRL = 0, regLin = 0, samples = 0):

    #fl  = 'scatter_lRate_' + `learningRate` + '_nLearning_' + `deepL` +  '_numHNeuronSM_' + `numHidNeuronsSM` +  '_numHNeuronRL_' + `numHidNeuronsRL` + '_yPred_' + yPred + '_useRouting__' + `useRouting` + '_normY_' + `normY` + \
    #        '_normR_' + `normR` + '_normT_' + `normT` + '_centerF_' + `centerF` + '_regSM_' + `regSM` + '_regRL_' + `regRL` + '_regLin_' + `regLin` + '_samples_' + `samples` + '_' + fileData
    fl  = 'scatter_' + fileData
    filename  = fl + '_1.png'
    filename2 = fl + '_2.png'
    
    
    # ConfigurationParameters
    maxEpoch = 4060 
    batchSize = 512
    validPercentage = 0.1
    testPercentage = 0.1
    useLB = 1
    
    ################# LOAD DATA SETS ############################
    
    nodes = 31
    nodesA = 12
    edgesA = 24
    edges = 56
    numPaths = 276
    pairs = nodesA*nodesA
    numFetR = pairs

    # Load Data 
    data = np.loadtxt(fileData)
    np.random.shuffle(data)
    if (samples != 0):
        data = data[0:samples,0:456]

    n = data.shape[0]
    routing = data[0:n,0:24]
    traffic = data[0:n,24:168]
    delay = data[0:n,168:456]
    
    routing = routing/normR
    traffic = traffic/normT
    if (centerF):
        routing -= np.mean(routing)
        traffic -= np.mean(traffic)

    Xo = np.concatenate((routing,traffic), axis=1)
    numFeat = Xo.shape[1]

    yi = delay/normY
    numOut = 12*12*2
    
    # Generate Dataset
    lastTraining = n*(1-validPercentage-testPercentage)
    lastValid = n*(1-testPercentage)
    X = Xo[0:lastTraining,:]
    y = yi[0:lastTraining,:]
    ds = mlD.DenseDesignMatrix(X=X, y=y)
    Xvalid = Xo[lastTraining:lastValid,:]
    yvalid = yi[lastTraining:lastValid,:]
    ds_valid = mlD.DenseDesignMatrix(X=Xvalid, y=yvalid)
    Xt = Xo[lastValid:n,:]
    yt = yi[lastValid:n,:]
    #ds_test = mlD.DenseDesignMatrix(X=Xt, y=yt)
    
    ################# CONFIGURE ANN ##################################
    #tc.EpochCounter(numEpoch)
    
    # Layers of the network
    hidden_layerSM = mlp.Sigmoid(layer_name='hiddenSM', dim=numHidNeuronsSM, irange=0.05, init_bias=1.)
    hidden_layerRL = mlp.RectifiedLinear(layer_name='hiddenRL', dim=numHidNeuronsRL, irange=0.05, init_bias=-0.2)
    output_layer = mlp.Linear(dim=numOut, layer_name='y', irange=0.05, init_bias=0.2)
    hidden_layerSM2 = mlp.Sigmoid(layer_name='hiddenSM2', dim=numHidNeuronsRL, irange=0.05, init_bias=1.)
    
    # Termination criterion
    termination_criterion = tc.MonitorBased(channel_name="valid_objective", N=50, prop_decrease=0.0)
    monitor_save_best = bp.MonitorBasedSaveBest( channel_name = 'valid_objective', save_path = 'bestANN.pkl')
    
    # Learning rate
    start = startPar
    saturate = saturatePar
    decay_factor = decayLR
    learning_rate_adjustor = sgd.LinearDecayOverEpoch(start, saturate, decay_factor)
    
    # Momentum
    initial_momentum = iniMomentum
    final_momentum = endMomentum
    start = startPar
    saturate = saturatePar
    momentum_adjustor = lr.MomentumAdjustor(final_momentum, start, saturate)
    momentum_rule = lr.Momentum(initial_momentum)
    

    # Regularization
    regulCost = mlp_costs.WeightDecay({'hiddenSM':regSM, 'hiddenRL':regRL, 'y':regLin, 'hiddenSM2':regSM})
    minCost = mlp_costs.Default()
    cost = costs.SumOfCosts(costs = [minCost, regulCost])
    
    # Trainer
    trainer = sgd.SGD(
        learning_rate=learningRate,
        batch_size=batchSize,
        monitoring_dataset= {'train': ds, 'valid': ds_valid},
        termination_criterion=termination_criterion,
        learning_rule=momentum_rule,
        cost = cost)
    
    # Select architecture
    if (deepL == 1):
        layers = [hidden_layerSM, output_layer]
    elif (deepL == 2):
        layers = [hidden_layerRL, output_layer]
    elif (deepL == 3):
        layers = [hidden_layerSM, hidden_layerRL, output_layer]
    elif (deepL == 4):
        layers = [hidden_layerRL, hidden_layerSM, output_layer]
    elif (deepL == 5):
        layers = [hidden_layerSM, hidden_layerSM2, output_layer]
    
    # Set Network
    ann = mlp.MLP(layers, nvis=numFeat)
    trainer.setup(ann, ds)
    
    
    ################# TRAIN NETWORK ###########################
    numEpochT = 0
    while True:
        trainer.train(dataset=ds)
        ann.monitor.report_epoch()
        ann.monitor()
        monitor_save_best.on_monitor(ann, ds_valid, trainer)
        if not trainer.continue_learning(ann) or numEpochT > maxEpoch:
            break
        numEpochT += 1
        momentum_adjustor.on_monitor(ann, ds_valid, trainer)
        learning_rate_adjustor.on_monitor(ann, ds_valid, trainer)
    
    
    ################# GENERATE RESULTS ##############################
    # Load best network
    ann = serial.load('bestANN.pkl')
    
    ## Generate output
    print '==============================================================='
    # Training set
    inputs = X 
    y_est_training = ann.fprop(theano.shared(inputs, name='inputs')).eval()
    mse_training = normY*normY*np.sum(np.power(y-y_est_training,2))/(y.size)
    print 'MSE training: ' + `mse_training`   
    plt.scatter(normY*y, normY*y_est_training)
    plt.savefig('training_' + filename)
    plt.scatter(normY*y[:,51], normY*y_est_training[:,51], color='red', alpha=0.2, s=8)
    plt.scatter(normY*y[:,4], normY*y_est_training[:,4], color='green', alpha=0.2, s=8)
    #plt.show()
    plt.savefig('training_' + filename2)
    print '==============================================================='
    
    # Validation set
    inputs = Xvalid 
    y_est_valid = ann.fprop(theano.shared(inputs, name='inputs')).eval()
    mse_valid = normY*normY*np.sum(np.power(yvalid-y_est_valid,2))/(yvalid.size)
    print 'MSE validation: ' + `mse_valid`   
    plt.scatter(normY*yvalid, normY*y_est_valid)
    plt.savefig('validation_' + filename)
    plt.scatter(normY*yvalid[:,51], normY*y_est_valid[:,51], color='red', alpha=0.6, s=8)
    plt.scatter(normY*yvalid[:,4], normY*y_est_valid[:,4], color='green', alpha=0.6, s=8)
    #plt.show()
    plt.savefig('validation_' + filename2)
    print '==============================================================='
    
    # Test set
    inputs = Xt 
    y_est_test = ann.fprop(theano.shared(inputs, name='inputs')).eval()
    mse_test = normY*normY*np.sum(np.power(yt-y_est_test,2))/(yt.size)
    print 'MSE test: ' + `mse_test`   
    plt.scatter(normY*yt, normY*y_est_test)
    plt.savefig('test_' + filename)
    plt.scatter(normY*yt[:,51], normY*y_est_test[:,51], color='red', alpha=0.6, s=8)
    plt.scatter(normY*yt[:,4], normY*y_est_test[:,4], color='green', alpha=0.6, s=8)
    #plt.show()
    plt.savefig('test_' + filename2)
    print '==============================================================='
    
    
    
    
    
    ################# PRINT RESULTS ##############################
    f = open('results.txt', 'a')
    f.write('Simulation: ' + datetime.now().strftime('%Y-%m-%d %H:%M:%S') + '\n')
    
    f.write('Training data:\n')
    f.write('- Prediction: ' + yPred + '\n')
    f.write('- Data: ' + fileData + '  (network: ' + `network` + ')\n')
    if (useRouting == 0):
        f.write('- Without routing  (0)\n')
    if (useRouting == 1):
        f.write('- Same routing for all pairs  (1)\n')
    if (useRouting == 2):
        f.write('- One routing per pair  (2)\n')
    f.write('- Samples: ' + `samples` + '\n')
        
    f.write('\nConfiguration:\n')
    f.write('- Normalization (traffic, routing, center, Y): ' + `normT` + ', ' + \
        `normR` + ', ' + `centerF` + ', ' + `normY` + '\n')
    
    f.write('- Initial learning rate: ' + `learningRate` + '\n')
    f.write('- Num Neurons Sigmoid: ' + `numHidNeuronsSM` + '\n')
    f.write('- Num Neurons Rectified: ' + `numHidNeuronsRL` + '\n')
    if (deepL == 1):
        f.write('- Layers: hidden_Sigmoig + output_linear  (1)\n')
    elif (deepL == 2):
        f.write('- Layers: hidden_Rectifier + output_linear  (2)\n')
    elif (deepL == 3):
        f.write('- Layers: hidden_Sigmoig + hidden_Rectifier + output_linear  (3)\n')
    elif (deepL == 4):
        f.write('- Layers: hidden_Rectifier + hidden_Sigmoig + output_linear  (4)\n')
    elif (deepL == 5):
        f.write('- Layers: hiddemSigmoid + hidden_Sigmoig + output_linear  (4)\n')
    f.write('- Regularization Sigmoid: ' + `regSM` + '\n')
    f.write('- Regularization Rectifier: ' + `regRL` + '\n')
    f.write('- Regularization Linear: ' + `regLin` + '\n')
    
    f.write('- StartEpoch: ' + `startPar` + '\n')
    f.write('- SaturateEpoch: ' + `saturatePar` + '\n')
    f.write('- DecayFactor Learning rate: ' + `decayLR` + '\n')
    f.write('- Initial momentim: ' + `iniMomentum` + '\n')
    f.write('- Final momentum: ' + `endMomentum` + '\n')

    #f.write('' + `` + '\n')
    
    f.write('\nResults:\n')
    f.write('- NumEpoch: ' + `numEpochT - 50` + '\n')
    f.write('- MSE training: ' + `mse_training` + '\n')
    f.write('- MSE valid: ' + `mse_valid` + '\n')
    f.write('- MSE test: ' + `mse_test` + '\n')
    f.write('===============================================================\n\n')
    
    f.close()


    f = open('resultsSingle.txt', 'a')
    f.write(datetime.now().strftime('%Y-%m-%d %H:%M:%S') + ';' + `yPred` + ';' + `fileData` + ';' + `useRouting` + ';' + `normT` + ';' + `normR` + ';' + `centerF` + ';' + `normY` + ';' + \
            `learningRate` + ';' + `numHidNeuronsSM` + ';' + `numHidNeuronsRL` + ';' + `deepL` + ';' + `regSM` + ';' + `regRL` + ';' + `regLin` + ';' + \
            `startPar` + ';' + `saturatePar` +  ';' + `decayLR` + ';' + `iniMomentum` + ';' + `endMomentum` +  ';' + \
            `numEpochT-50` + ';' + `mse_training` + ';' + `mse_valid` + ';' + `mse_test` + '\n') 
    f.close()

    np.savetxt('resultsY_est.txt', y_est_test)
    np.savetxt('resultsY_test.txt', yt)

if __name__ == "__main__":
    runML()

#if not os.path.exists():
#    os.makedirs(directory)
