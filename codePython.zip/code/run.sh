#!/bin/sh
# It requires pylearn2

NETW=3
FILE=dataLong_2.txt

python sysTest.py -S 6400 -l 0.01 -f 500 -n 200 -m 200 -d 1 -o $FILE -N $NETW -y paths -u 2 -s 20 -p 200 -a 0.4 -i 0.2 -j 0.8 -w 0 -x 0 -z 0 -r 1 

